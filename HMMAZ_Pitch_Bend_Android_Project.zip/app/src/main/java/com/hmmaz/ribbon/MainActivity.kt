package com.hmmaz.ribbon

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var bend = 0
    private var transpose = -2
    private var preset = 1
    private lateinit var bendLabel: TextView
    private lateinit var ribbon: View
    private val blue = Color.rgb(16, 105, 165)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(Color.rgb(12,12,15))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("PEDAL") { toast("PEDAL: not assigned") }, weight(1f))
        top.addView(button("PEDAL: NONE") { toast("Pedal setting") }, weight(1.4f))
        top.addView(button("RESET") { bend = 0; updateBend() }, weight(0.8f))
        top.addView(button("−") { transpose--; updateTranspose() }, weight(.6f))
        val tr = TextView(this).apply { text = "TRANSPOSE\n$transpose"; setTextColor(Color.WHITE); gravity=Gravity.CENTER; textSize=15f }
        top.addView(tr, weight(1f))
        top.addView(button("+") { transpose++; updateTranspose() }, weight(.6f))
        top.addView(button("BACK →") { toast("HMMAZ Pitch Bend") }, weight(.8f))
        root.addView(top, LinearLayout.LayoutParams(-1, 52))
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        for (i in 1..5) row.addView(button("$i") { preset=i; toast("Preset $i selected") }, weight(1f))
        row.addView(button("RESET") { bend=0; updateBend() }, weight(1.2f))
        root.addView(row, LinearLayout.LayoutParams(-1, 48))
        val keys = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(0,6,0,6) }
        val vals = listOf("-50","-50","-13","-30","-50","-50","-50")
        vals.forEachIndexed { i, value ->
            val key = TextView(this).apply {
                text = "  $value\n\n$value"; gravity=Gravity.CENTER; textSize=12f
                setTextColor(Color.DKGRAY); setBackgroundColor(if(i==2||i==3||i==6) Color.rgb(245,55,65) else Color.WHITE)
            }
            keys.addView(key, LinearLayout.LayoutParams(0, 68, 1f))
        }
        root.addView(keys)
        bendLabel = TextView(this).apply { text="PITCH BEND: 0"; setTextColor(Color.WHITE); gravity=Gravity.CENTER; textSize=14f }
        root.addView(bendLabel, LinearLayout.LayoutParams(-1, 28))
        ribbon = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(5,8,20), Color.rgb(30,40,70), Color.rgb(5,8,20))).apply {
                cornerRadius=60f; setStroke(3, Color.rgb(35,45,70))
            }
        }
        val ribbonBox = FrameLayout(this).apply {
            setPadding(22,12,22,12)
            addView(ribbon, FrameLayout.LayoutParams(-1, 88))
            val center = View(this@MainActivity).apply { setBackgroundColor(Color.CYAN) }
            addView(center, FrameLayout.LayoutParams(2,88,Gravity.CENTER))
        }
        ribbon.setOnTouchListener { _, event ->
            val w = ribbon.width.coerceAtLeast(1)
            when(event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val x = event.x.coerceIn(0f,w.toFloat()) / w
                    bend = ((x*16383f).roundToInt()-8192).coerceIn(-8192,8191)
                    updateBend(); true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { bend=0; updateBend(); true }
                else -> true
            }
        }
        root.addView(ribbonBox, LinearLayout.LayoutParams(-1, 116))
        root.addView(TextView(this).apply { text="HMMAZ  •  USB MIDI connection prototype"; setTextColor(Color.GRAY); gravity=Gravity.CENTER; textSize=11f }, LinearLayout.LayoutParams(-1, 24))
        setContentView(root)
    }
    private fun button(label:String, action:()->Unit): TextView = TextView(this).apply {
        text=label; gravity=Gravity.CENTER; textSize=13f; setTextColor(Color.WHITE)
        setPadding(4,8,4,8)
        background=GradientDrawable().apply { setColor(if(label=="RESET") Color.RED else blue); cornerRadius=7f; setStroke(1,Color.rgb(100,150,190)) }
        setOnClickListener { action() }
    }
    private fun weight(w:Float)=LinearLayout.LayoutParams(0,-1,w).apply { setMargins(3,2,3,2) }
    private fun updateBend(){ bendLabel.text="PITCH BEND: $bend" }
    private fun updateTranspose(){ (findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout)?.let { } ; toast("Transpose: $transpose") }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
